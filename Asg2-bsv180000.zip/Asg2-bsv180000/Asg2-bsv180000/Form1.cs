﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Media;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace Asg2_bsv180000
{

    public partial class Form1 : Form
    {
        //time1 variable to store timestamp of 
        String time1;

        //variable to store number of times backspace is pressed
        int backspace_count;

        public Form1()
        {
            InitializeComponent();
        }

        //Add Button Function
        private void addButton_Click(object sender, EventArgs e)
        {
            String timeStamp2 = GetTimestamp(DateTime.Now);
            StringBuilder sb = new StringBuilder();
            sb.Append(firstNameBox.Text);
            sb.Append(" ");
            sb.Append(middleInitialBox.Text);
            sb.Append(" ");
            sb.Append(lastNameBox.Text);
            sb.Append("\t");
            sb.Append(phoneNumberBox.Text);

            //Adding Items to the list View
            rebateDatalist.Items.Add(sb.ToString());

            using (StreamWriter sw = File.AppendText("CS6326Asg2.txt"))
            {
                sw.Write(firstNameBox.Text); sw.Write("\t");
                sw.Write(middleInitialBox.Text); sw.Write("\t");
                sw.Write(lastNameBox.Text); sw.Write("\t");
                sw.Write(addressLine1Box.Text); sw.Write("\t");
                sw.Write(addressline2Box.Text); sw.Write("\t");
                sw.Write(cityBox.Text); sw.Write("\t");
                sw.Write(stateBox.Text); sw.Write("\t");
                sw.Write(zipCodeBox.Text); sw.Write("\t");
                sw.Write(genderDropBox.Text); sw.Write("\t");
                sw.Write(phoneNumberBox.Text); sw.Write("\t");
                sw.Write(emailBox.Text); sw.Write("\t");
                sw.Write(purchaseproofDropBox.Text); sw.Write("\t");
                sw.Write(dateRecievedBox.Text); sw.Write("\t");
                sw.Write(this.time1); sw.Write("\t");
                sw.Write(timeStamp2); sw.Write("\t");
                sw.Write(backspace_count);
                sw.Write("\n");
                sw.Close();
            }

            foreach (Control c in Controls)
            {
                if (c is TextBox)
                {
                    c.Text = "";
                }

                if (c is ComboBox)
                {
                    c.Text = "";
                }
            }
            firstNameBox.Focus();
            closureDisplayBox.Text = "New Entry Added";
            this.backspace_count = 0;
        }

        private void firstNameBox_TextChanged(object sender, EventArgs e)
        {
            this.time1 = GetTimestamp(DateTime.Now);
            addButton.Enabled = true;
        }

        //First Function to be called when Form Loads
        private void Form1_Load_1(object sender, EventArgs e)
        {
            if(File.Exists("CS6326Asg2.txt"))
            {
                StreamReader sr = new StreamReader("CS6326Asg2.txt");

                while (true)
                {
                    String line = sr.ReadLine();
                    if (line == null)
                        break;
                    String[] myArray = line.Split('\t').ToArray();
                    String list = myArray[0] + " " + myArray[1] + " " + myArray[2] + "\t" + myArray[9];
                    rebateDatalist.Items.Add(list);

                }

                sr.Close();
            }
        }

        private void rebateDatalist_SelectedIndexChanged(object sender, EventArgs e)
        {
            modifyButton.Enabled = true;
            deleteButton.Enabled = true;
            Console.Write(rebateDatalist.SelectedIndex);
        }

        private void modifyButton_Click(object sender, EventArgs e)
        {
            String line = rebateDatalist.SelectedItem.ToString();
            Console.WriteLine(line);
            closureDisplayBox.Text = "Modified the Entry";
            modifyButton.Enabled = false;

        }

        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmssffff");
        }

        private void KeyPress(object sender, KeyPressEventArgs e)
        {
            if((int)e.KeyChar == 8)
            {
                this.backspace_count++;
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            foreach (Control c in Controls)
            {
                if (c is TextBox)
                {
                    c.Text = "";
                }
                if (c is ComboBox)
                {
                    c.Text = "";
                }
            }
            firstNameBox.Focus();
            rebateDatalist.Items.RemoveAt(rebateDatalist.SelectedIndex);
            closureDisplayBox.Text = "Deleted the Entry Successfully";
            deleteButton.Enabled = false;
        }
    }
}
